
//jscript for meter to other unit conversion

document.getElementById('meter-submit').addEventListener('click', ()=>{
    event.preventDefault();
    let convMeter = document.getElementById('meter-input').value;
    
    document.getElementById('meter-inches').value = convMeter * 39.370;
    document.getElementById('meter-feet').value = convMeter * 3.281;
    document.getElementById('meter-yard').value = convMeter * 1.094;
});

//reset button for meter conversion

document.getElementById('meter-reset').addEventListener('click', ()=>{
    event.preventDefault();
    let convMeter = document.getElementById('meter-input').value = document.getElementById('meter-input').innerHTML;
    
    document.getElementById('meter-inches').value = convMeter;
    document.getElementById('meter-feet').value = convMeter;
    document.getElementById('meter-yard').value = convMeter;
});

//js for INCHES to Feet, Yard and Meter

document.getElementById('inches-submit').addEventListener('click', ()=>{
    event.preventDefault();
    let convInch = document.getElementById('inches-input').value;
    
    document.getElementById('inches-feet').value = convInch * 0.833;
    document.getElementById('inches-yard').value = convInch * 0.028;
    document.getElementById('inches-meter').value = convInch / 39.37;
});


//reset button for inches conversion

document.getElementById('inches-reset').addEventListener('click', ()=>{
    event.preventDefault();
    let convInch = document.getElementById('inches-input').value = document.getElementById('inches-input').innerHTML;
    
    document.getElementById('inches-feet').value = convInch;
    document.getElementById('inches-yard').value = convInch;
    document.getElementById('inches-meter').value = convInch;
});

//js for FEET to Yard, Meter and Inches

document.getElementById('feet-submit').addEventListener('click', function(){
    event.preventDefault();

    let convFeet = document.getElementById('feet-input').value;

    document.getElementById('feet-yard').value = convFeet * 0.33;
    document.getElementById('feet-meter').value = convFeet / 3.281;
    document.getElementById('feet-inches').value = convFeet * 12;
})

//reset button for feet conversion

document.getElementById('feet-reset').addEventListener('click', function(){
    event.preventDefault();

    let convFeet = document.getElementById('feet-input').value = document.getElementById('feet-input').innerHTML;
    
    document.getElementById('feet-yard').value = convFeet;
    document.getElementById('feet-meter').value = convFeet;
    document.getElementById('feet-inches').value = convFeet;
})

// js for YARD to Meter, Inches and Feet conversion

document.getElementById('yard-submit').addEventListener('click', function (){
    event.preventDefault();

    let convYard = document.getElementById('yard-input').value;

    document.getElementById('yard-meter').value = convYard / 1.094;
    document.getElementById('yard-inches').value = convYard * 36;
    document.getElementById('yard-feet').value = convYard * 3;
})

// Reset button for Yard conversion

document.getElementById('yard-reset').addEventListener('click', function(){
    event.preventDefault();

    let convYard = document.getElementById('yard-input').value = document.getElementById('yard-input').innerHTML;

    document.getElementById('yard-meter').value = convYard;
    document.getElementById('yard-inches').value = convYard;
    document.getElementById('yard-feet').value = convYard;
})

// End of script